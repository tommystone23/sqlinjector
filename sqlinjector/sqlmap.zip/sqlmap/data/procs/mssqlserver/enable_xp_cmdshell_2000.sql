EXEC master..sp_addextendedproc 'xp_cmdshell', @dllname='xplog70.dll'
